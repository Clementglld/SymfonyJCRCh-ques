<?php

namespace App\Controller;

use App\Entity\Donnees;
use App\Form\DonneesType;
use App\Repository\DonneesRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/donnees")
 */
class DonneesController extends AbstractController
{
    /**
     * @Route("/", name="donnees_index", methods={"GET"})
     */
    public function index(DonneesRepository $donneesRepository): Response
    {
        return $this->render('donnees/index.html.twig', [
            'donnees' => $donneesRepository->findAll(),
        ]);
    }

    /**
     * @Route("/new", name="donnees_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $donnee = new Donnees();
        $form = $this->createForm(DonneesType::class, $donnee);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($donnee);
            $entityManager->flush();

            return $this->redirectToRoute('donnees_index');
        }

        return $this->render('donnees/new.html.twig', [
            'donnee' => $donnee,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="donnees_show", methods={"GET"})
     */
    public function show(Donnees $donnee): Response
    {
        return $this->render('donnees/show.html.twig', [
            'donnee' => $donnee,
        ]);
    }

    /**
     * @Route("/{id}/edit", name="donnees_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Donnees $donnee): Response
    {
        $form = $this->createForm(DonneesType::class, $donnee);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('donnees_index');
        }

        return $this->render('donnees/edit.html.twig', [
            'donnee' => $donnee,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="donnees_delete", methods={"DELETE"})
     */
    public function delete(Request $request, Donnees $donnee): Response
    {
        if ($this->isCsrfTokenValid('delete'.$donnee->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($donnee);
            $entityManager->flush();
        }

        return $this->redirectToRoute('donnees_index');
    }
}
