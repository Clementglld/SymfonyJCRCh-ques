<?php

namespace App\Entity;

use App\Repository\DonneesRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=DonneesRepository::class)
 */
class Donnees
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="float")
     */
    private $licence;

    /**
     * @ORM\Column(type="float")
     */
    private $prixEveil;

    /**
     * @ORM\Column(type="float")
     */
    private $prixJudo;

    /**
     * @ORM\Column(type="float")
     */
    private $prixTaiso;

    /**
     * @ORM\Column(type="string", length=100)
     */
    private $banqueJDC;

    /**
     * @ORM\Column(type="string", length=15)
     */
    private $numBancaireJDC;

    /**
     * @ORM\Column(type="string", length=50)
     */
    private $beneficiaire;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLicence(): ?float
    {
        return $this->licence;
    }

    public function setLicence(float $licence): self
    {
        $this->licence = $licence;

        return $this;
    }

    public function getPrixEveil(): ?float
    {
        return $this->prixEveil;
    }

    public function setPrixEveil(float $prixEveil): self
    {
        $this->prixEveil = $prixEveil;

        return $this;
    }

    public function getPrixJudo(): ?float
    {
        return $this->prixJudo;
    }

    public function setPrixJudo(float $prixJudo): self
    {
        $this->prixJudo = $prixJudo;

        return $this;
    }

    public function getPrixTaiso(): ?float
    {
        return $this->prixTaiso;
    }

    public function setPrixTaiso(float $prixTaiso): self
    {
        $this->prixTaiso = $prixTaiso;

        return $this;
    }

    public function getBanqueJDC(): ?string
    {
        return $this->banqueJDC;
    }

    public function setBanqueJDC(string $banqueJDC): self
    {
        $this->banqueJDC = $banqueJDC;

        return $this;
    }

    public function getNumBancaireJDC(): ?string
    {
        return $this->numBancaireJDC;
    }

    public function setNumBancaireJDC(string $numBancaireJDC): self
    {
        $this->numBancaireJDC = $numBancaireJDC;

        return $this;
    }

    public function getBeneficiaire(): ?string
    {
        return $this->beneficiaire;
    }

    public function setBeneficiaire(string $beneficiaire): self
    {
        $this->beneficiaire = $beneficiaire;

        return $this;
    }
}
