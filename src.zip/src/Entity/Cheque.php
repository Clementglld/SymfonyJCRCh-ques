<?php

namespace App\Entity;

use App\Repository\ChequeRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ChequeRepository::class)
 */
class Cheque
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="date")
     */
    private $date;

    /**
     * @ORM\Column(type="string", length=15)
     */
    private $numeroCheque;

    /**
     * @ORM\Column(type="float")
     */
    private $montantCheque;

    /**
     * @ORM\ManyToOne(targetEntity=Banque::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $uneBanque;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->date;
    }

    public function setDate(\DateTimeInterface $date): self
    {
        $this->date = $date;

        return $this;
    }

    public function getNumeroCheque(): ?string
    {
        return $this->numeroCheque;
    }

    public function setNumeroCheque(string $numeroCheque): self
    {
        $this->numeroCheque = $numeroCheque;

        return $this;
    }

    public function getMontantCheque(): ?float
    {
        return $this->montantCheque;
    }

    public function setMontantCheque(float $montantCheque): self
    {
        $this->montantCheque = $montantCheque;

        return $this;
    }

    public function getUneBanque(): ?Banque
    {
        return $this->uneBanque;
    }

    public function setUneBanque(?Banque $uneBanque): self
    {
        $this->uneBanque = $uneBanque;

        return $this;
    }

   
}
