<?php

namespace App\Form;

use App\Entity\Donnees;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class DonneesType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('licence')
            ->add('prixEveil')
            ->add('prixJudo')
            ->add('prixTaiso')
            ->add('banqueJDC')
            ->add('numBancaireJDC')
            ->add('beneficiaire')
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Donnees::class,
        ]);
    }
}
